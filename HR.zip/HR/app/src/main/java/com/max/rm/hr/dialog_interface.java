package com.max.rm.hr;

import android.app.AlertDialog;

public interface dialog_interface {
    public void onDialogOkClick(AlertDialog alertDialog);
    public void onDialogCancelClick(AlertDialog alertDialog);

}
