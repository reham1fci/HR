package com.max.rm.hr.Employee.infoPkg;

public class info_financial_class  {
    String name;
    String price;

    public info_financial_class(String name, String price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public String getPrice() {
        return price;
    }
}
