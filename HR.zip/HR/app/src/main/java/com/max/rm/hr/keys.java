package com.max.rm.hr;

public class keys  {
    public static  final  String VACACTION= "vacation";
    public static  final  String CUSTODY= "custody";
    public static  final  String CLASS_NAME= "class_name";
    public static  final  String PERMISSION= "permission";
    public static  final  String LOAN= "loan";
    public static  final  String IS_USED= "isUsed";
    public static  final  String IS_REJECTED= "isRejected";
    public static  final  String OTHER= "other";
    public static  final  String addButton= "add_button";
    public static  final  String allEmployee= "all";
    public static  final  String TASK= "task";

}
