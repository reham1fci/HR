package com.max.rm.hr.Employee;

/**
 * Created by Eng.Reham Mokhtar on 28/5
 */

public interface RequestInterface {
    public void onResponse(String response);
    public void onError();
}
