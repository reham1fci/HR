package com.max.rm.hr.Employee.infoPkg;

import android.view.View;

public interface rec_interface {
    public void onRecItemSelected(int position, View view);
}
