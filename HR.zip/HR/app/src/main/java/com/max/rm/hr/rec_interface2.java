package com.max.rm.hr;

import android.view.View;

import com.max.rm.hr.Employee.employee_class;

import java.util.ArrayList;

public interface rec_interface2 {
    public void onRecItemSelected(int position, View view, ArrayList<employee_class>list);
}
