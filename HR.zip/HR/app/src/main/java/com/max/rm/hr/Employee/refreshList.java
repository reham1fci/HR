package com.max.rm.hr.Employee;

public interface refreshList {
    public void onDelete(int position);
    public void onEdit(int position, String id);
}
